<?php
    if($idioma == "pt"){
        $frasefooter = "Todos os direitos reservados.";
    }else{
        $frasefooter = "All rights reserved.";
    }
?>

<p><strong>2012 &copy; Dauphin Creative Company - <i><?php echo $frasefooter; ?></i></strong></p>

