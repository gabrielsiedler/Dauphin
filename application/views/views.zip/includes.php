<link rel="shortcut icon" href="<?php echo base_url(); ?>imagens/favicon.png" type="image"/>
<link rel="stylesheet" href="<?php echo base_url(); ?>css/style.css" type="text/css"/>
<link href="<?php echo base_url(); ?>fonts/fontes.css?family=Droid+Sans:400,700" rel="stylesheet" type="text/css"/>

<!--[if IE]>
    <script type="text/javascript" src="<?php echo base_url(); ?>js/html5-min.js"></script>
<![endif]-->

<script type="text/javascript" src="<?php echo base_url(); ?>js/jquery-1.7.1-min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/jquery.easing-min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/jquery.animate-colors-min.js"></script>

<script type="text/javascript" src="<?php echo base_url(); ?>js/switcher-min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/scripts-min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/sprites-min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/fundo-min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/googleMap-min.js"></script> 

<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>
